﻿namespace Form1
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Arg1 = new System.Windows.Forms.TextBox();
            this.textBox_Arg2 = new System.Windows.Forms.TextBox();
            this.comboBox1_Mop = new System.Windows.Forms.ComboBox();
            this.button_Calculate = new System.Windows.Forms.Button();
            this.textBox_Result = new System.Windows.Forms.TextBox();
            this.button_Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_Arg1
            // 
            this.textBox_Arg1.Location = new System.Drawing.Point(138, 12);
            this.textBox_Arg1.Name = "textBox_Arg1";
            this.textBox_Arg1.Size = new System.Drawing.Size(121, 20);
            this.textBox_Arg1.TabIndex = 2;
            // 
            // textBox_Arg2
            // 
            this.textBox_Arg2.Location = new System.Drawing.Point(138, 90);
            this.textBox_Arg2.Name = "textBox_Arg2";
            this.textBox_Arg2.Size = new System.Drawing.Size(121, 20);
            this.textBox_Arg2.TabIndex = 3;
            // 
            // comboBox1_Mop
            // 
            this.comboBox1_Mop.FormattingEnabled = true;
            this.comboBox1_Mop.Location = new System.Drawing.Point(138, 53);
            this.comboBox1_Mop.Name = "comboBox1_Mop";
            this.comboBox1_Mop.Size = new System.Drawing.Size(121, 21);
            this.comboBox1_Mop.TabIndex = 4;
            // 
            // button_Calculate
            // 
            this.button_Calculate.Location = new System.Drawing.Point(138, 128);
            this.button_Calculate.Name = "button_Calculate";
            this.button_Calculate.Size = new System.Drawing.Size(121, 64);
            this.button_Calculate.TabIndex = 5;
            this.button_Calculate.Text = "Вычислить";
            this.button_Calculate.UseVisualStyleBackColor = true;
            this.button_Calculate.Click += new System.EventHandler(this.button_Calculate_Click);
            // 
            // textBox_Result
            // 
            this.textBox_Result.Location = new System.Drawing.Point(138, 219);
            this.textBox_Result.Name = "textBox_Result";
            this.textBox_Result.Size = new System.Drawing.Size(121, 20);
            this.textBox_Result.TabIndex = 6;
            // 
            // button_Clear
            // 
            this.button_Clear.Location = new System.Drawing.Point(138, 294);
            this.button_Clear.Name = "button_Clear";
            this.button_Clear.Size = new System.Drawing.Size(121, 80);
            this.button_Clear.TabIndex = 7;
            this.button_Clear.Text = "Очистить";
            this.button_Clear.UseVisualStyleBackColor = true;
            this.button_Clear.Click += new System.EventHandler(this.button_Clear_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(454, 461);
            this.Controls.Add(this.button_Clear);
            this.Controls.Add(this.textBox_Result);
            this.Controls.Add(this.button_Calculate);
            this.Controls.Add(this.comboBox1_Mop);
            this.Controls.Add(this.textBox_Arg2);
            this.Controls.Add(this.textBox_Arg1);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Калькулятор";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox_Arg1;
        private System.Windows.Forms.TextBox textBox_Arg2;
        private System.Windows.Forms.ComboBox comboBox1_Mop;
        private System.Windows.Forms.Button button_Calculate;
        private System.Windows.Forms.TextBox textBox_Result;
        private System.Windows.Forms.Button button_Clear;
    }
}

