﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Form1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            comboBox1_Mop.Items.Add("+");
            comboBox1_Mop.Items.Add("-");
            comboBox1_Mop.Items.Add("*");
            comboBox1_Mop.Items.Add("/");

            comboBox1_Mop.SelectedIndex = 0;
        }

        private void button_Calculate_Click(object sender, EventArgs e)
        {
            try
            {
                string sx1 = textBox_Arg1.Text;
                int x1 = Convert.ToInt32(sx1);

                string sx2 = textBox_Arg2.Text;
                int x2 = Convert.ToInt32(sx2);

                string mop = comboBox1_Mop.SelectedItem.ToString();
                double result = 0;

                if (mop == "+")
                {
                    result = x1 + x2;
                }
                else if (mop == "-")
                {
                    result = x1 - x2;
                }
                else if (mop == "*")
                {
                    result = x1 * x2;
                }
                else
                {
                    result = x1 / x2;
                }

                textBox_Result.Text = " = " + result;
            }
            catch (DivideByZeroException)
            {
                textBox_Result.Text = "Деление на 0!";
            }
            catch (FormatException)
            {
                textBox_Result.Text = "Это НЕ число!";
            }
        }

        private void button_Clear_Click(object sender, EventArgs e)
        {
            textBox_Arg1.Text = "";
            textBox_Arg2.Text = "";
            textBox_Result.Text = "";
            comboBox1_Mop.SelectedIndex = 0;
        }
    }
}
